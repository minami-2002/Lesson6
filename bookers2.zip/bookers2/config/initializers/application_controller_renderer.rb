# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '079c8b9944517e4ea7564dd502bc6778801cf57b93a7ac6505658a4498400028ef922252e5161b0fe45b107b0c5478cd96224b393e0fda8169151fe4851eabe0'